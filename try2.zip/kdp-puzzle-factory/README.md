# KDP Puzzle Factory

A free GitHub Actions repo that automatically generates a kids puzzle book interior PDF for Amazon KDP.

## What it creates

- Trivia pages
- Word search puzzles
- Crossword-style clue pages
- Answer key pages
- Print-ready 8.5 x 11 inch PDF interior
- Downloadable artifact from GitHub Actions

## How to use on GitHub

1. Create a new GitHub repository.
2. Upload all files from this ZIP.
3. Go to the **Actions** tab.
4. Click **Build KDP Puzzle Book**.
5. Click **Run workflow**.
6. Download the generated PDF from the workflow **Artifacts** section.

## Change book theme

Open `scripts/generate_book.py` and change:

```python
BOOK_TITLE = "Dinosaur Trivia & Puzzle Fun"
THEME = "dinosaurs"
```

You can use themes like:

- dinosaurs
- space
- animals
- ocean
- fairy tales
- India facts

## KDP Settings

Recommended:
- Interior: Black & white
- Trim size: 8.5 x 11 inches
- Bleed: No bleed
- Paper: White paper
- Cover: Create separately in Canva

## Important

This is a starter automation repo. Before uploading to KDP, always review the PDF manually.
